import { Developers } from '../../models/developers';
import { AppDataSource } from '../../data-source';
import { Like } from 'typeorm';

interface IRequest {
    query?: string;
    page: number;
    pageSize: number;
  }

class FindAllDevelopers {
    public async execute({query, page, pageSize}: IRequest): Promise<{ developers: Developers[], totalPages: number }> {
        const developerRepository = AppDataSource.getRepository(Developers);

        const [developers, totalDevelopers] = await developerRepository.findAndCount({
            where: query ? { nome: Like(`%${query}%`) } : {},
            skip: (page - 1) * pageSize,
            take: pageSize,
        });

        const totalPages = Math.ceil(totalDevelopers / pageSize);

        return { developers, totalPages };
    }
}

export { FindAllDevelopers };