import React from 'react';

import LevelList from '../components/LevelList';


const LevelPage: React.FC = () => {

  return (
    <div>
      <LevelList/>
    </div>
  );
};

export default LevelPage;