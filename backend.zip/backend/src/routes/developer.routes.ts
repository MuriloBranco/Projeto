import { Request, Response, Router } from 'express';
import { DevelopersRepository } from 'src/repositories/implementations/DeveloperRepository';

const developerRouter = Router();
const teste = []

developerRouter.get('/api/niveis', async (request: Request, response: Response) => {

  return response.status(200).json();
});

export default developerRouter;
