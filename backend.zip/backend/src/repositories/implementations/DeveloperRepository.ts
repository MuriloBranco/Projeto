import { Repository } from "typeorm";
import { IDeveloperRepository, IDeveloperDTO } from "../IDeveloperRepository";
import { Developers } from "../../entity/developers";
import { AppDataSource } from "../../data-source";



class DevelopersRepository implements IDeveloperRepository {
  private ormRepository: Repository<Developers>;

  constructor() {
    this.ormRepository = AppDataSource.getRepository(Developers);
  }

  findById(id: number): Promise<Developers | undefined> {
    const developer = this.ormRepository.findOne({ where: { id } });
    return developer;
  }

  save(item: IDeveloperDTO): Promise<Developers> {
    const developer = this.ormRepository.save(item);
    return developer;
  }

  async insert(nivel_id: IDeveloperDTO): Promise<Developers> {
    const developer = this.ormRepository.create(nivel_id);
    await this.ormRepository.save(developer);
    return developer;
  }

  findOneOrFailCustom(options: any, error: any): Promise<Developers> {
    const developer = this.ormRepository.findOneOrFail(options).catch(() => {
      throw error;
    });
    return developer;
  }
}

export default DevelopersRepository ;